-- Safe schema additions. These CREATE TABLE IF NOT EXISTS statements will not remove existing data.
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('consumer','creator') NOT NULL DEFAULT 'consumer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS videos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) DEFAULT '',
  name VARCHAR(255) DEFAULT '',
  filename VARCHAR(255) NOT NULL,
  username VARCHAR(255) DEFAULT '', -- stores uploader username (string) for compatibility
  publisher VARCHAR(255) DEFAULT '',
  producer VARCHAR(255) DEFAULT '',
  genre VARCHAR(100) DEFAULT '',
  age_rating VARCHAR(50) DEFAULT '',
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS comments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  video_id INT NOT NULL,
  username VARCHAR(255) NOT NULL,
  comment TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (video_id),
  INDEX (username)
);

CREATE TABLE IF NOT EXISTS likes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  video_id INT NOT NULL,
  username VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_like (video_id, username),
  INDEX (video_id),
  INDEX (username)
);
